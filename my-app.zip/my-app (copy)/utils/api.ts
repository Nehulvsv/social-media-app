import axios from "axios";


const API_BASE_URL = 'http://127.0.0.1:8000/api';

const api = axios.create(
  {
    baseURL: API_BASE_URL,
    withCredentials:true

  }

)

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original_request = error.config;

    // Check for 401 error and ensure this is not a retry of the token refresh request
    if (error.response?.status === 401 && !original_request._retry) {
      original_request._retry = true;

      try {
        // Attempt to refresh the token
        const re = await api.post('/token/refresh/');
        console.log('re ===== ',re);
        console.log('Token refreshed successfully. Retrying original request...');
        return api(original_request); // Retry the original request
      } catch (refreshError) {
        console.error('Token refresh failed:', refreshError);

        // Clear tokens and redirect to login
        document.cookie = 'access_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        document.cookie = 'refresh_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        window.location.href = '/login';

        throw refreshError;
      }
    }

    // Handle other errors
    throw error;
  }
);



interface Tokens {
  access: string;
  refresh: string;
}

let tokens: Tokens | null = null;

export async function login(username: string, password: string): Promise<boolean> {
  try {
    const response = await api.post('/token/' ,{username,password});
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
}

export async function logout(): Promise<boolean> {
  try {
    const response = await api.post('/logout/' );
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
}

export async function get_auth(): Promise<boolean> {
  try {
    const response = await api.get('/status/');
    console.log('response.data ===== ',response);
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
}

export async function register(data: { email: string; password: string; username: string; firstName: string; lastName: string }): Promise<boolean> {
  try {
    const response = await api.post('/register/' ,{data});
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
}

export async function fetchProfile(username): Promise<any> {
  try {
    const response = await api.get(`/my-profile/${username}`);
    return response.data;
  
  } catch (error) {
    console.error('Fetch profile error:', error);
    throw error;
  }
}

export async function toggleFollow(username :  string): Promise<any> {
  try {
    const response = await api.post(`/follow/` , {username});
    return response.data;
  
  } catch (error) {
    console.error('Fetch profile error:', error);
    throw error;
  }
}


export async function fetchPosts(username :  string): Promise<any> {
  try {
    const response = await api.get(`/posts/${username}`);
    return response.data;
  
  } catch (error) {
    console.error('Fetch profile error:', error);
    throw error;
  }
}


export async function toggleLike(id :  number): Promise<any> {
  try {
    const response = await api.post(`/toggle-like` ,{id});
    return response.data;
  
  } catch (error) {
    console.error('Fetch profile error:', error);
    throw error;
  }
}

export async function createPost(content:string): Promise<any> {
  try {
    const response = await api.post(`/create-post` ,{content});
    return response.data;
  
  } catch (error) {
    console.error('error:', error);
    throw error;
  }
}

export async function allPost(): Promise<any> {
  try {
    const response = await api.get(`/all-posts` );
    return response.data;
  
  } catch (error) {
    console.error('error:', error);
    throw error;
  }
}