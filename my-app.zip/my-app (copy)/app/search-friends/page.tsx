'use client'

import { useState } from 'react'
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

// Mock data for friends
const mockFriends = [
  { id: 1, name: 'Alice Johnson', username: '@alice' },
  { id: 2, name: 'Bob Smith', username: '@bob' },
  { id: 3, name: 'Charlie Brown', username: '@charlie' },
  { id: 4, name: 'Diana Prince', username: '@diana' },
]

export default function SearchFriends() {
  const [searchTerm, setSearchTerm] = useState('')
  const [searchResults, setSearchResults] = useState(mockFriends)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const results = mockFriends.filter(friend => 
      friend.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      friend.username.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setSearchResults(results)
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-semibold mb-6">Search Friends</h1>
        
        <form onSubmit={handleSearch} className="mb-8">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Search by name or username"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-200"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
            >
              Search
            </button>
          </div>
        </form>

        <div className="space-y-4">
          {searchResults.map(friend => (
            <div key={friend.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 bg-gray-100">
                  <AvatarFallback className="text-gray-400">
                    {friend.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{friend.name}</p>
                  <p className="text-gray-500 text-sm">{friend.username}</p>
                </div>
              </div>
              <button
                className="px-4 py-1.5 border rounded-lg hover:bg-gray-50 transition-colors text-sm"
              >
                Add Friend
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

