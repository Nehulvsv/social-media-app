// 'use client'

// import { useEffect, useState } from 'react'
// import { fetchProfile } from '@/utils/api'
// import { UserCircle } from 'lucide-react'

// interface ProfileData {
//   name: string;
//   username: string;
//   bio: string;
//   follower_count: number;
//   following_count: number;
//   profile_image: string;
// }

// export function UserProfile({username}) {
//   const [profile, setProfile] = useState<ProfileData | null>(null)
//   const [isLoading, setIsLoading] = useState(true)
//   const [error, setError] = useState<string | null>(null)

//   useEffect(() => {
//     async function loadProfile() {
//       try {
//         const data = await fetchProfile(username)
//         setProfile(data.data)
//       } catch (err) {
//         setError('Failed to load profile')
//       } finally {
//         setIsLoading(false)
//       }
//     }

//     loadProfile()
//   }, [])

//   if (isLoading) {
//     return <div className="text-center">Loading profile...</div>
//   }

//   if (error) {
//     return <div className="text-center text-red-500">{error}</div>
//   }

//   if (!profile) {
//     return <div className="text-center">No profile data available</div>
//   }

//   return (
//     <div className="flex flex-col items-center text-center space-y-4">
//       <div className="relative">
//         {profile.profile_image ? (
//           <img
//             src={`http://127.0.0.1:8000/api${profile.profile_image}` }
//             alt={profile.username}
//             className="h-24 w-24 rounded-full overflow-auto"
//           />
//         ) : (
//           <UserCircle className="h-24 w-24 text-gray-300" />
//         )}
//       </div>
//       <div className="space-y-2">
//         <h1 className="text-2xl font-bold text-gray-900">{profile.first_name}</h1>
//         <p className="text-gray-500">{profile.username}</p>
//         <p className="text-gray-700 max-w-md mx-auto">{profile.bio}</p>
//       </div>
//       <div className="flex space-x-6">
//         <div className="text-center">
//           <span className="block font-semibold text-gray-900">{profile.follower_count}</span>
//           <span className="text-gray-500 text-sm">Followers</span>
//         </div>
//         <div className="text-center">
//           <span className="block font-semibold text-gray-900">{profile.following_count}</span>
//           <span className="text-gray-500 text-sm">Following</span>
//         </div>
//       </div>
//     </div>
//   )
// }

"use client";

import { useEffect, useState } from "react";
import { fetchProfile, toggleFollow } from "@/utils/api";
import {
  UserCircle,
  MapPin,
  LinkIcon,
  Calendar,
  Edit,
  UserMinus,
  UserPlus,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProfileData {
  name: string;
  username: string;
  bio: string;
  follower_count: number;
  following_count: number;
  profile_image: string;
  post_count: number;
  location?: string;
  website?: string;
  joined?: string;
  is_our_profile: boolean;
  following: boolean;
}

interface UserProfileProps {
  username: string;
}

export function UserProfile({ username }: UserProfileProps) {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    async function loadProfile() {
      try {
        const data = await fetchProfile(username);
        setProfile(data.data);
        setIsFollowing(data.data.following);
      } catch (err) {
        setError("Failed to load profile");
      } finally {
        setIsLoading(false);
      }
    }

    loadProfile();
  }, [username]);

  if (isLoading) {
    return <div className="text-center">Loading profile...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>;
  }

  if (!profile) {
    return <div className="text-center">No profile data available</div>;
  }

  const handleToggleFollow = async () => {
    if (!profile) return;

    try {
      // Toggle the follow status on the server
      const newFollowStatus = await toggleFollow(username);

      // Update the profile state
      setProfile((prev) => {
        if (!prev) return null;
        console.log("newFollowStatus.success ===== ", newFollowStatus.success);
        const newFollowerCount =
          newFollowStatus.success == true
            ? prev.follower_count + 1
            : prev.follower_count - 1;

        return {
          ...prev,
          follower_count: newFollowerCount,
          following: newFollowStatus,
        };
      });

      // Update the isFollowing state
      setIsFollowing(newFollowStatus.success);
    } catch (err) {
      console.error("Failed to toggle follow status", err);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="relative h-48 bg-gradient-to-r from-blue-500 to-purple-500">
        {profile.profile_image ? (
          <img
            src={`http://127.0.0.1:8000/api${profile.profile_image}`}
            alt={profile.username}
            // className="h-24 w-24 rounded-full overflow-auto"
            className="absolute bottom-0 left-6 -mb-12 h-32 w-32 rounded-full border-4 border-white object-cover"
          />
        ) : (
          <UserCircle className=" text-gray-300 absolute bottom-0 left-6 -mb-12 h-32 w-32 rounded-full border-4 border-white object-cover" />
        )}
      </div>
      <div className="pt-16 px-6 pb-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{profile.name}</h1>
            <p className="text-gray-500">@{profile.username}</p>
          </div>

          {profile.is_our_profile ? (
            <Button variant="outline" className="flex items-center gap-2">
              <Edit className="h-4 w-4" />
              Edit Profile
            </Button>
          ) : (
            <Button
              variant={isFollowing ? "outline" : "default"}
              className="flex items-center gap-2"
              onClick={handleToggleFollow}
            >
              {isFollowing ? (
                <>
                  <UserMinus className="h-4 w-4" />
                  Unfollow
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4" />
                  Follow
                </>
              )}
            </Button>
          )}
        </div>
        <p className="text-gray-700 mb-4">{profile.bio}</p>
        <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-4">
          {profile.location && (
            <span className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {profile.location || "surat"}
            </span>
          )}
          {profile.website && (
            <a
              href={profile.website}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-blue-500"
            >
              <LinkIcon className="h-4 w-4" />
              {profile.website}
            </a>
          )}
          {profile.joined && (
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              Joined {profile.joined}
            </span>
          )}
        </div>
        <div className="flex gap-4 text-sm">
          <span className="font-semibold text-gray-900">
            {profile.post_count}{" "}
            <span className="font-normal text-gray-500">Posts</span>
          </span>
          <span className="font-semibold text-gray-900">
            {profile.follower_count}{" "}
            <span className="font-normal text-gray-500">Followers</span>
          </span>
          <span className="font-semibold text-gray-900">
            {profile.following_count}{" "}
            <span className="font-normal text-gray-500">Following</span>
          </span>
        </div>
      </div>
    </div>
  );
}
