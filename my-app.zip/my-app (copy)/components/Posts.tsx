"use client";

import { useEffect, useState } from "react";
import { fetchPosts, toggleLike } from "@/utils/api";
import { Heart, UserCircle } from "lucide-react";

interface Post {
  content: string;
  image: string | null;
  like_count: number;
  comments: number;
  formatted_date: string;
  username: string;
  id: number;
  like_by_me: boolean; // Track if the post is liked by the user
}

interface PostsProps {
  username: string;
}

export function Posts({ username }: PostsProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadPosts() {
      try {
        const data = await fetchPosts(username);
        setPosts(data.posts);
      } catch (err) {
        setError("Failed to load posts");
      } finally {
        setIsLoading(false);
      }
    }

    loadPosts();
  }, [username]);

  if (isLoading) {
    return <div className="text-center">Loading posts...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>;
  }

  if (posts.length === 0) {
    return <div className="text-center">No posts available</div>;
  }

  const handleToggleLike = async (id: number) => {
    try {
      const newLikeStatus = await toggleLike(id);
      setPosts((prevPosts) =>
        prevPosts.map((post) =>
          post.id === id
            ? {
                ...post,
                like_count: newLikeStatus.success
                  ? post.like_count + 1
                  : post.like_count - 1,
                like_by_me: newLikeStatus.success,
              }
            : post
        )
      );
    } catch (err) {
      console.error("Failed to toggle like status", err);
    }
  };

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <article
          key={post.id}
          className="bg-white rounded-lg shadow-sm overflow-hidden"
        >
          <div className="p-4">
            {/* Display username */}
            <div className="flex items-center space-x-2 mb-4">
              {post.image ? (
                <img
                  src={post.image}
                  alt={post.username}
                  className="h-12 w-12 rounded-full border-4 border-white object-cover"
                />
              ) : (
                <UserCircle className="text-gray-300 h-14 w-14" />
              )}
              <span className="font-semibold text-gray-900">@{post.username}</span>
            </div>

            {/* Post content */}
            <p className="text-gray-700 mb-4">{post.content}</p>
            {post.image && (
              <img
                src={post.image}
                alt="Post content"
                className="w-full h-64 object-cover rounded-md mb-4"
              />
            )}
            <div className="flex justify-between items-center text-sm text-gray-500">
              <div className="flex space-x-4">
                <button
                  className="flex items-center space-x-1 hover:text-red-500"
                  onClick={() => handleToggleLike(post.id)}
                >
                  <Heart
                    className={`h-5 w-5 ${
                      post.like_by_me ? "fill-current text-red-500" : "text-gray-500"
                    }`}
                  />
                  <span>{post.like_count}</span>
                </button>
              </div>
              <span>{post.formatted_date}</span>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
