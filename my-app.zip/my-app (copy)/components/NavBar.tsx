'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { MoreHorizontal } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import Cookies from 'js-cookie'; // Use js-cookie for cookie management
import { useAuthContext } from '@/app/context/useAuth';
import { useRouter } from 'next/navigation';


export function NavBar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const { authLoading, auth_login, auth_logout } = useAuthContext();
  const router = useRouter();
  // Check localStorage for username
  // useEffect(() => {
  //   const username = localStorage.getItem('username');
  //   setIsLoggedIn(!!username);
  // }, []);

  // Logout handler
  const handleLogout = async () => {
    try {
      Cookies.remove('access_token', { path: '/' });
      Cookies.remove('refresh_token', { path: '/' });
      await auth_logout();
      router.push('/login'); // Use Next.js router for navigation
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <nav className="sticky top-0 z-50 border-b bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          <Link href="/" className="text-xl font-bold">
            SocialApp
          </Link>
          <Sheet>
            <SheetTrigger asChild>
              <button
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="Open menu"
              >
                <MoreHorizontal className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent>
              <nav className="flex flex-col space-y-4 mt-8">
                {/* <Link
                  href="/"
                  className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                >
                  Profile
                </Link> */}
                <Link
                  href="/new-post"
                  className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                >
                  New Post
                </Link>
                <Link
                  href="/search-friends"
                  className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                >
                  Search Friends
                </Link>
                <div className="border-t my-4" />
                {!authLoading ? (
                  <button
                    onClick={handleLogout}
                    className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                  >
                    Logout
                  </button>
                ) : (
                  <>
                    <Link
                      href="/login"
                      className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                    >
                      Login
                    </Link>
                    <Link
                      href="/register"
                      className="text-lg hover:text-gray-900 text-gray-600 transition-colors"
                    >
                      Register
                    </Link>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
